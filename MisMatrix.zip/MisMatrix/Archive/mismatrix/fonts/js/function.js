
// Some constants
var gIsReloading = false;
window.gSources = [];
window.gDisplays = [];




// Start script
auth(); // Start authication







// Login
function auth(){
  //alert("Hello");
  var username = "administrator";
  var password = "admin";
  var server = window.location.protocol + "//" + window.location.host + "/" + window.location.pathname;
  var user = 0;

  setUser(user);


};

setUser = function(user) {
  user = user;
  if (user > 0) {
    console.info("User is already logged");
  } else {
    console.Error("Authicate user..");
    // Check what happen when somebody click on 'LOGIN'
  }
};
